$(function()
{
	
	let drop_block,
		drop_files,
		i,
		file,
		file_format,
		file_name,
		posi,
		menu = {
			
			name	: '',
			sticker : 'menu ul:nth-child(2)',
			spoiler : 'menu ul:nth-child(3)',
			rims    : 'menu ul:nth-child(4)'
			
		};
	
	$('section:nth-of-type(2) ul li:not(:last-child) input').attr('disabled', 'disabled');
	
	$('section:nth-of-type(2) ul li:last-child input').on('click', function()
	{
		
		window.print();
		
	});
	
//Вычисление координат
	function pos()
	{
		
		posi = $('.drag').position();
							
		$('.drag').attr({
							
			'title'      : 'Координаты — X: ' + posi.left + ', Y: ' + posi.top,
			'data-left'  : posi.left,
			'data-top' 	 : posi.top
							
		});
		
	}
	
//Дроп
	$(window).on('dragover', function( e )
	{

		e.preventDefault();

		drop_block = e.target.className;
		
		if( drop_block.match('drop-area') !== null )
		{
			
			$('.' + drop_block).addClass('drop-area-hover');
			
		}
		else
		{
			
			$('.drop-area').removeClass('drop-area-hover');
			e.originalEvent.dataTransfer.dropEffect = "none";
			
		}

	});
	
	$('.drop-area').on('drop', function( e )
	{
		
		e.preventDefault();
		
		$( '.' + drop_block ).removeClass('drop-area-hover');
		
		if ( !e.originalEvent.dataTransfer ||
			 !e.originalEvent.dataTransfer.files.length )
			return false;

		drop_files = e.originalEvent.dataTransfer.files;
			
		file 		= drop_files[0]['name'].split('.');
		file_name 	= file[0];
		file_format = file[1];
			
		if ( file_format == 'jpg' || file_format == 'png' )
		{
				
			let reader = new FileReader();
				
			reader.onload = (function( e )
			{
					
				$('section:nth-child(4) img').attr('src', e.target.result);

			});
				
			reader.readAsDataURL( drop_files[0] );
				
		}
		else
			alert( 'Неподдерживаемый файл: ' + file.join('.') + '\nК загрузке разрешены форматы только: jpg и png.' );
			
	});
	
//Меню
	$('menu > ul:nth-child(n+3)').hide();
	
	$('menu ul:first-child li').on('click', function()
	{
		
		$('menu ul:not(:first-child)').hide();
		
		menu.name = $(this).children().attr('name');

		$( menu[ menu.name ] ).show();
		
		
	});
	
//Тюнинг, лол
	$(document).on('click', 'menu ul:not(:first-child) li, .ui-draggable', function()
	{
		
		$('.drag').removeClass('drag').draggable('disable');

		if ( !$(this).attr('class') || !$(this).attr('class').match('ui-draggable') )
		{
			
			$('figure').append
			(
		
				$(this).children().clone().addClass('drag')
		
			);
			
			$('.drag').css({
				
					position : 'absolute',
					left	 : '50%',
					top 	 : '50%'
				
				}).draggable({
					
					drag: function()
					{

						pos();
						
					}
					
				});
			
		}
		else
			$(this).addClass('drag').draggable('enable');
		
		$('section:nth-of-type(2) ul li input').removeAttr('disabled');
		
	});
	
//Тюнинг для тюнинга, лол
	$('section:nth-of-type(2) ul li:not(:last-child) input').on('click', function()
	{
		
		i = $(this).attr('name');
		
		if ( i == 'width-plus' )
		{

			i = $('.drag').width() + 1;
			$('.drag').css( 'width', i + 'px' );
			
		}
		else if ( i == 'width-minus' )
		{
			
			i = $('.drag').width() - 1;
			$('.drag').css( 'width', i + 'px' );
					
		}
		else if ( i == 'height-minus' )
		{
			
			i = $('.drag').height() - 1;
			$('.drag').css( 'height', i + 'px' );
					
		}
		else if ( i == 'height-plus' )
		{
			
			i = $('.drag').height() + 1;
			$('.drag').css( 'height', i + 'px' );
					
		}

	});
	
//Клавиши
	$(document).on('keypress keydown', function( e )
	{
		
		if ( !$('.drag').length )
			return;
		
		e.preventDefault();
		
		if ( e.which == 99 || e.which == 67 || e.which == 1089 || e.which == 1057 )
		{
			
			$('.drag').remove();
			
			$('section:nth-of-type(2) ul li:not(:last-child) input').attr('disabled', 'disabled');
			
			return;
			
		}
		else if ( e.which == 38 ) //Вверх
		{
			
			$('.drag').css(
			
				'top', parseInt($('.drag').css('top')) - 1 + 'px'
			
			);
			
		}
		else if ( e.which == 40 ) //Вниз
		{
			
			$('.drag').css(
			
				'top', parseInt($('.drag').css('top')) + 1 + 'px'
			
			);
			
		}
		else if ( e.which == 39 ) //Вправо
		{
			
			$('.drag').css(
			
				'left', parseInt($('.drag').css('left')) + 1 + 'px'
			
			);
			
		}
		else if ( e.which == 37 ) //Влево
		{
			
			$('.drag').css(
			
				'left', parseInt($('.drag').css('left')) - 1 + 'px'
			
			);
			
		}
		
		pos();
		
	});
	
//Сброс выделения
	$(document).on('click', function( e )
	{

		let name = e.target.className.match('ui-draggable'),
			tagName = ( e.target.offsetParent ) ? e.target.offsetParent.tagName : '',
			optName = $(e.target).get(0).tagName;

		if ( name !== null || tagName == 'MENU' || optName == 'INPUT' )
			return;
		else
		{
			
			$('.drag').removeClass('drag').draggable('disable');
			
			$('section:nth-of-type(2) ul li:not(:last-child) input').attr('disabled', 'disabled');
			
		}
		
	});
	
});